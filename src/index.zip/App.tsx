import ParkingLotDashboard from "./pages/ParkingLotsDashboard"
import './App.css'

function App() {


  return <ParkingLotDashboard />
  
}

export default App
