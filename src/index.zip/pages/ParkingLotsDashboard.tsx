import { useEffect, useState } from "react"
import axios from "axios"

interface Lot {
  id: number
  name: string
  cnt: number
}

export default function ParkingLotDashboard() {
  const [lots, setLots] = useState<Lot[]>([])
  const [selectedLot, setSelectedLot] = useState<Lot | null>(null)
  const [parkingData, setParkingData] = useState({
    available_spaces: 0,
    long_parked: 0,
    total_spaces: 0,
  })

  useEffect(() => {
    axios.get<Lot[]>("http://localhost:8000/ParkingLots/").then(res => {
      setLots(res.data)
      setSelectedLot(res.data[0])
    })
  }, [])

  useEffect(() => {
    if (selectedLot) {
      axios
        .get<{ available_spaces: number; long_parked: number; total_spaces: number }>(`http://localhost:8000/static/parking_${selectedLot.id}.json`)
        .then(res => setParkingData(res.data))
        .catch(() => setParkingData({ available_spaces: 0, long_parked: 0, total_spaces: 0 }))
    }
  }, [selectedLot])

  return (
    <div className="min-h-screen bg-white text-black p-8 font-sans">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="flex-1">
          <h1 className="text-4xl font-bold mb-4">{selectedLot?.name || "주차장"}</h1>
          <img
            src={`http://localhost:8000/static/predicted${selectedLot?.id}.jpg`}
            alt="주차장 이미지"
            className="w-full rounded-xl shadow"
          />
          <div className="mt-4 space-y-2 text-lg">
            <p>총 주차공간: {parkingData.total_spaces}</p>
            <p>남은 주차공간: {parkingData.available_spaces}</p>
            <p>장기 주차 탐지: {parkingData.long_parked}대</p>
          </div>
        </div>

        <div className="w-full md:w-1/4">
          <h2 className="text-2xl font-semibold mb-4">다른 구역</h2>
          <div className="space-y-2">
            {lots.map((lot) => (
              <button
                key={lot.id}
                onClick={() => setSelectedLot(lot)}
                className={`w-full px-4 py-2 rounded-lg border ${
                  selectedLot?.id === lot.id ? "bg-black text-white" : "bg-gray-100 hover:bg-gray-200"
                }`}
              >
                {lot.name}
              </button>
            ))}
          </div>

          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-2">시간대별 변화 그래프</h3>
            <img
              src="http://localhost:8000/static/graph.png"
              alt="그래프"
              className="w-full rounded shadow"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
